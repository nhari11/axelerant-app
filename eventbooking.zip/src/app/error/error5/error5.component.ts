import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error5',
  templateUrl: './error5.component.html',
  styleUrls: ['./error5.component.css']
})
export class Error5Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
