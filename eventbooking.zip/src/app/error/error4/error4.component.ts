import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error4',
  templateUrl: './error4.component.html',
  styleUrls: ['./error4.component.css']
})
export class Error4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
