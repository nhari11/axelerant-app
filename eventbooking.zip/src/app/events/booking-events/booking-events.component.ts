import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-events',
  templateUrl: './booking-events.component.html',
  styleUrls: ['./booking-events.component.css']
})
export class BookingEventsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
